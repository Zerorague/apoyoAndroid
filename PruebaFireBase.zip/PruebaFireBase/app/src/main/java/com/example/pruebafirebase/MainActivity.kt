package com.example.pruebafirebase

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.util.PatternsCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.pruebafirebase.databinding.ActivityMainBinding
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val btnLogin = binding.btnLogin

        btnLogin.setOnClickListener {
            val email = binding.itLoginUsuario
            val password = binding.itLoginPassword
            validarCorreo(email)
            validarPassword(password)

        }



    }

    private fun validarPassword(password: TextInputEditText):Boolean {
        val pattern = "[a-zA-Z0-9\\w]{4,12}".toRegex()
        val matcher = pattern.matches(password.text.toString())
        if (!matcher){
            password.setError("La contraseña debe tener entre 4 y 12 caracteres")
        }
        return matcher

    }

    private fun validarCorreo(email: TextInputEditText):Boolean {
        val matcher = PatternsCompat.EMAIL_ADDRESS.matcher(email.text.toString()).matches()
        if (!matcher){
            email.setError("Formato email incorrecto")

        }
        return matcher
    }


}