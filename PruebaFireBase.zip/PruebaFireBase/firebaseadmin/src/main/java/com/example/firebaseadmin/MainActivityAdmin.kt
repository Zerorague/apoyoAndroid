package com.example.firebaseadmin

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.firebaseadmin.databinding.ActivityMainAdminBinding

class MainActivityAdmin : AppCompatActivity() {
    private lateinit var binding: ActivityMainAdminBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainAdminBinding.inflate(layoutInflater)
        setContentView(binding.root)


        val btnUpload = binding.btnUpload
        val btnLeer = binding.btnBuscar

        btnLeer.setOnClickListener {
            val intent=Intent(this,LeerActivity::class.java)
            startActivity(intent)
            finish()
        }

        btnUpload.setOnClickListener {
            val intent = Intent(this, UploadActivity::class.java)
            startActivity(intent)
            finish()
        }

    }
}