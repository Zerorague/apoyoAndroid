package com.example.firebaseadmin

data class TaxiData(val nombreDuenio:String?=null,val marcaAuto:String?=null, val modeloAuto:String?=null,val patenteAuto:String?=null){}

