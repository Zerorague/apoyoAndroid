package com.example.firebaseadmin

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.firebaseadmin.databinding.ActivityLeerBinding
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class LeerActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLeerBinding
    private lateinit var databaseReference: DatabaseReference
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLeerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val btnBuscarPatente = binding.btnBuscarPatente
        val btnVolver = binding.btnVolver
        val btnEditar = binding.btnActualizarPatente
        btnVolver.setOnClickListener {
            val intent = Intent(this, MainActivityAdmin::class.java)
            startActivity(intent)
            finish()
        }
        btnBuscarPatente.setOnClickListener {
            val patente = binding.itBuscarPatente.text.toString()
            if (!patente.isNullOrEmpty()) {
                leerDatos(patente)
            } else {
                Toast.makeText(this, "es obligatorio poner una patente", Toast.LENGTH_SHORT).show()
            }
        }

        btnEditar.setOnClickListener {

            val patenteAuto = binding.itBuscarPatente.text.toString()
            val modeloAuto = binding.itBuscarModelo.text.toString()
            val marcaAuto = binding.itBuscarMarca.text.toString()
            val nombreDuenio = binding.itBuscarNombreDuenio.text.toString()
            actualizarDatos(nombreDuenio, marcaAuto, modeloAuto, patenteAuto)


        }

    }

    private fun actualizarDatos(
        nombreDuenio: String,
        marcaAuto: String,
        modeloAuto: String,
        patenteAuto: String
    ) {
        databaseReference = FirebaseDatabase.getInstance().getReference("Datos Taxis")
        val patenteAutoAux = binding.itBuscarPatenteAux.text.toString()
        val datosTaxi = mapOf<String, String>(
            nombreDuenio to nombreDuenio,
            marcaAuto to marcaAuto,
            modeloAuto to modeloAuto
        )
        val data = databaseReference.child(patenteAutoAux).updateChildren(datosTaxi)
        data.addOnSuccessListener {
            Toast.makeText(
                this,
                "Datos de vehiculo $patenteAuto actualizados correctamente",
                Toast.LENGTH_SHORT
            ).show()
            limpiarFormulario()
        }
        data.addOnFailureListener {
            Toast.makeText(
                this,
                "Error al actualizar datos de vehiculo $patenteAuto",
                Toast.LENGTH_SHORT
            ).show()


        }
    }

    private fun limpiarFormulario() {
        binding.itBuscarMarca.text?.clear()
        binding.itBuscarModelo.text?.clear()
        binding.itBuscarNombreDuenio.text?.clear()
        binding.itBuscarPatente.text?.clear()

    }

    private fun leerDatos(patente: String) {
        databaseReference = FirebaseDatabase.getInstance().getReference("Datos Taxis")
        val data = databaseReference.child(patente).get()
        data.addOnSuccessListener {
            if (it.exists()) {
                val nombreDuenio = it.child("nombreDuenio").value.toString()
                val marcaAuto = it.child("marcaAuto").value.toString()
                val modeloAuto = it.child("modeloAuto").value.toString()
                val patenteAuto = it.child("patenteAuto").value.toString()
                Toast.makeText(
                    this,
                    "es se encontraron datos para la patente $patente",
                    Toast.LENGTH_SHORT
                ).show()

                binding.itBuscarPatente.setText(patente)
                binding.itBuscarNombreDuenio.setText(nombreDuenio.toString())
                binding.itBuscarMarca.setText(marcaAuto.toString())
                binding.itBuscarModelo.setText(modeloAuto.toString())
                binding.itBuscarPatenteAux.setText(patenteAuto.toString())
            } else {
                Toast.makeText(this, "no existen datos para patente $patente", Toast.LENGTH_SHORT)
                    .show()
            }
        }
        data.addOnFailureListener {
            Toast.makeText(
                this,
                "error al buscar datos para la patente $patente",
                Toast.LENGTH_SHORT
            ).show()

        }
    }
}