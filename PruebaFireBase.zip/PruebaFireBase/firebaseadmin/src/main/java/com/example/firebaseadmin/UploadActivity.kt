package com.example.firebaseadmin

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.firebaseadmin.databinding.ActivityUploadBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class UploadActivity : AppCompatActivity() {
    private lateinit var binding: ActivityUploadBinding
    private lateinit var databaseReference: DatabaseReference
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUploadBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val btnCrearRegistro = binding.btnCrearRegistro


        //success listener

        btnCrearRegistro.setOnClickListener {
            val nombreDuenio = binding.itNombreDuenio.text.toString()
            val marcaAuto = binding.itMarcaAuto.text.toString()
            val modeloAuto = binding.itModeloAuto.text.toString()
            val patenteAuto = binding.itPatenteAuto.text.toString()

            val datosTaxi: TaxiData = TaxiData(nombreDuenio, marcaAuto, modeloAuto, patenteAuto)


            if (validarDatos(datosTaxi)) {
                databaseReference = FirebaseDatabase.getInstance().getReference("Datos Taxis")

                val registroPatente =
                    FirebaseDatabase.getInstance().getReference("Datos Taxis/" + patenteAuto)
                registroPatente.addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        if (!snapshot.exists()) {
                            insertaData(databaseReference, datosTaxi)

                        } else {
                            Toast.makeText(
                                this@UploadActivity,
                                "error: Patente ya existe en el sistema",
                                Toast.LENGTH_SHORT
                            ).show()
                            habilitarBoton()
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {
                        Toast.makeText(
                            this@UploadActivity,
                            "error: La base de datos no esta disponible",
                            Toast.LENGTH_SHORT
                        ).show()
                        habilitarBoton()

                    }
                })

            } else {
                Toast.makeText(
                    this@UploadActivity,
                    "error: Debe ingresar un valor para la patente",
                    Toast.LENGTH_SHORT
                ).show()
                habilitarBoton()

            }
        }

    }

    private fun insertaData(databaseReference: DatabaseReference, datosTaxi: TaxiData) {

        val dbRef = databaseReference.child(datosTaxi.patenteAuto.toString()).setValue(datosTaxi)
        dbRef.addOnSuccessListener {
            binding.itNombreDuenio.text?.clear()
            binding.itMarcaAuto.text?.clear()
            binding.itModeloAuto.text?.clear()
            binding.itPatenteAuto.text?.clear()



            val intent = Intent(this, MainActivityAdmin::class.java)

            startActivity(intent)
            finish()
            Toast.makeText(this, "Datos guardados correctamente", Toast.LENGTH_SHORT).show()
            //volver a la principal
        }
        dbRef.addOnFailureListener {
            Toast.makeText(this, "Error en el guardado de los datos", Toast.LENGTH_SHORT).show()

        }


    }

    private fun validarDatos(datosTaxi: TaxiData): Boolean {
        if (datosTaxi.patenteAuto.toString().isNullOrEmpty())
            return false
        else
            return true
    }

    private fun deshabilitarBoton() {
        binding.btnCrearRegistro.isEnabled = false
        binding.btnCrearRegistro.isClickable = false
    }

    private fun habilitarBoton() {
        binding.btnCrearRegistro.isEnabled = true
        binding.btnCrearRegistro.isClickable = true
    }

}